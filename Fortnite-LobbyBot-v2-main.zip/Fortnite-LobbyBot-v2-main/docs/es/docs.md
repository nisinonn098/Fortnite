## Documentación

### Glosario
Por favor leelo si no sabes la definición de algunas palabras en la documentación  
[Glosario](glossary.md "glossary.md")  

### Configuración
Documentación de la configuración  
[Configuración](config.md "config.md")  

### Comandos
Documentación de los comandos  
[Comandos](commands.md "commands.md")  

### Comandos personalizados
Documentación de los comandos personalizados  
[Comandos personalizados](custom_commands.md "custom_commands.md")  

### Respuestas
Documentación de las respuestas  
[Respuestas](replies.md "replies.md")  
