## Procedimiento hasta el primer arranque
[PC](pc.md "pc.md")  
・Arrancará usando recursos del PC, la limitación y la degradación del rendimiento son menores  
・Pero sólo puedes arrancar el bot mientras el PC está encendido  

[Repl.it](repl.md "repl.md")  (PC/Móvil)  
・No necesita poner archivos en su dispositivo, puede arrancar el bot aunque el dispositivo esté apagado  
・Pero hay liimitaciones de repl.it  

## Procedimiento hasta el setup
**Explicaré asumiendo que ya abriste la página web**
Deberías ver el editor de configuración, pon el email del bot, owner, etc...  
Documentación de las configuraciónes están [aquí](config.md "config.md")  
**Si usa repl y no establece la 'Contraseña para el servidor web`, otras personas pueden ver la configuración de su bot**  

Una vez terminado de configurar, presiona el botón Guardar en la parte inferior derecha y el bot se reiniciará  
Después de reiniciar, compruebe los logs y siga los pasos ahi.  
(Llamamos a esto autorización)  
![log](https://user-images.githubusercontent.com/53356872/104097033-72ac2100-52df-11eb-83c4-01090359abf4.png)  

Después de la autorización el bot debería arrancar  

**Esto es solo la primera vez, no lo necesitarás hacer de nuevo a no ser que agregues una nueva cuenta**  
Para ejecutar el bot, si estas en PC ejecuta el bot en la carpeta donde lo guardaste  
Si estás en repl encuentra tu proyecto [aquí](https://repl.it/repls "repl.it")  
