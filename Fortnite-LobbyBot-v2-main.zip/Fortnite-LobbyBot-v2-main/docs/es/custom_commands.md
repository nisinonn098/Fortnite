## Comandos personalizados
|  Valor (Valor Raw)  |  Descripción  |
| ---- | ---- |
|  Ejecutar cuando (run_when)  |  Especifica cuando los comandos personalizados serán ejecutados  |

### Comandos (commands)
|  Valor (Raw value)  |  Descripción  |
| ---- | ---- |
|  Palabra (word)  |  Palabra que ejecutará este comando personalizado  |
|  Permitir comandos (allow_for)  |  Tipos de usuarios que pueden ejecutar este comando personalizado  |
|  Comandos (run)  |  Comandos que ejecutará este comando personalizado  |
