## Procedure until the first startup in Repl.it  
Please wait a while...  
~~[Video]()~~  

First, access to [repl.it](https://repl.it "repl.it")  
If you don't have account yet, click `Sign up` on top right  
If you have already, click `Login` to login account  
(I don't explain how to make account or how to get email address)  

![Repl.it](https://user-images.githubusercontent.com/53356872/103261666-a173ee80-49e5-11eb-9ed3-314a469c29d2.png)  

After login, you will see screen like this, them press + mark on top right  
And press `Import From Github` tab on screen which displayed  
Paster `https://github.com/gomashio1596/Fortnite-LobbyBot-v2` in `Paste any repository URL` and click `Import from Github` button  

![Repl.it](https://user-images.githubusercontent.com/53356872/103262347-0defed00-49e8-11eb-9463-ebacf3370aab.png)  

If page has switched (We call this page `Project page`)  
Click `Run` button on top (If you are on phone, triangle button on bottom right)  
and wait until bot has booted (It'll take a while)  
We call `Console` tab log or console  
If bot has booted, click `Open in a new tab` button on top right (If you are on phone, open `Web` tab and top right)  
(We call page which will open in this time Web page)  

![Repl.it](https://user-images.githubusercontent.com/53356872/103263729-06324780-49ec-11eb-9b3f-f1eafcb4b17b.png)  

If page has opened, proceed to bot's [setup](setup.md#Procedure-to-setup "setup.md")  
