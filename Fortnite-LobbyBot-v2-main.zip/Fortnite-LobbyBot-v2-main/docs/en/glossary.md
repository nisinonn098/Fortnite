## Glossary
Fortnite
```
An online video game developed by Epic Games and released in 2017
```

Fortnite client
```
Fortnite which everyone usually play
```

Fortnite server
```
A base system of game which do various communication with Fortnite client
Match result and locker's data, party functions etc are server-side
```

Bot
```
A program which communicate with Fortnite server and imitate Fortnite client's functions
Not limited to Fortnite-LobbyBot
It's not Fortnite bot which will found in match
```

Web
```
In here it's a webpage which Fortnite-LobbyBot will boot
```

License
```
A rule of use
```

Python
```
One of programming language
Feature is code readability, many libraries etc
```

Avatar
```
An icon which shows in friend list and can be configured in party hub
```

Status
```
A text which shows in friend list
```
