## Documentation

### Glossary
Please read if you don't understand definition of words in documentation
[Glossary](glossary.md "glossary.md")  

### Config
Documentation of config  
[Config](config.md "config.md")  

### Commands
Documentation of commands  
[Commands](commands.md "commands.md")  

### Custom commands
Documentation of custom commands  
[Custom commands](custom_commands.md "custom_commands.md")  

### Replies
Documentation of replies  
[Replies](replies.md "replies.md")  
