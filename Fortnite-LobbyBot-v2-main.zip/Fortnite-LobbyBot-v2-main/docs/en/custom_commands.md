## Custom commands
|  Key (Raw value)  |  Description  |
| ---- | ---- |
|  Run when (run_when)  |  Specify when custom commands will be runned  |

### Commands (commands)
|  Key (Raw value)  |  Description  |
| ---- | ---- |
|  Word (word)  |  Word which need to trigger this custom command  |
|  Allow command for (allow_for)  |  User types who can runs this custom command  |
|  Run command (run)  |  Commands which runs in this custom command  |
